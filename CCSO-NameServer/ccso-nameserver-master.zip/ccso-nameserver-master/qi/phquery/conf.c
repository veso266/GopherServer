char *OkAddrs[]={0};
char *LocalAddrs[]={".uiuc.edu",".cecer.army.mil",0};
#include <sys/param.h>
#include "conf.h"
char *Strings[] = {
  "QI_ALT","ns1.uiuc.edu",
  "TEMPFILE","/tmp/qiXXXXXX",
  "NOHELP","nohelp",
  "HELPDIR","/var/apps/nameserv/help",
  "MAILBOX","email",
  "QI_HOST","ns.uiuc.edu",
  "ADMIN","p-pomes@uiuc.edu",
  "MAILDOMAIN","uiuc.edu",
  "DATABASE","/var/apps/nameserv/db/prod",
  "RUNDIR","/var/apps/nameserv/db",
  "PASSW","CCSO Resource Center",
  "MAILFIELD","alias",
  "NATIVESUBDIR","native",
0 };
char *Database = NULL;
