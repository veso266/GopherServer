
The files in this directory are documentation for the Unix Ph client.  These
docs were written especially for the University of Illinois and, thus,
there a references to things that only apply to UIUC.  (Also, we have
a VM/CMS client and the docs address special issues related to that
platform as well.

Feel free to download these files and use them as is or modify them to
suit the needs of your own institution.  Please do acknowledge, however, that
the original source was from UIUC and written by Lynn Ward and Carolyn Gendney.

Currently, there are two files in this directory.  One is a pagemaker 4.2
version and the other is raw postscript.  I've test the postscript file on a 
couple different models of Apple LaserWriters and it seems to print fine
from a Unix machine with the lpr command.  If you have difficulty printing the
PS file, let me know and I'll see what I can do.  

Soon, we will be uploading a "no-frills" ASCII version of the doc.  For now,
these are the files you'll find:

ph.ps  =  postscript version
ph.pm4.2.sit.hqx  =  stuffed/binhexed Pagemaker 4.2 file for the Mac.

Enjoy

Comments to: L-ward1@uiuc.edu
